const express = require("express");
const path = require("path");
const { spawn } = require("child_process");

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));

function weightedIntervalDpJs(jobs) {
  const sorted = [...jobs]
    .map((job, index) => ({ ...job, originalIndex: index }))
    .sort((a, b) => a.end - b.end);

  const ends = sorted.map((j) => j.end);
  const p = sorted.map((job, i) => {
    let lo = 0;
    let hi = i - 1;
    let ans = -1;
    while (lo <= hi) {
      const mid = Math.floor((lo + hi) / 2);
      if (ends[mid] <= job.start) {
        ans = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    return ans;
  });

  const dp = Array(sorted.length).fill(0);
  const take = Array(sorted.length).fill(false);

  for (let i = 0; i < sorted.length; i += 1) {
    const include = sorted[i].profit + (p[i] >= 0 ? dp[p[i]] : 0);
    const exclude = i > 0 ? dp[i - 1] : 0;
    if (include >= exclude) {
      dp[i] = include;
      take[i] = true;
    } else {
      dp[i] = exclude;
    }
  }

  const selected = [];
  let i = sorted.length - 1;
  while (i >= 0) {
    const include = sorted[i].profit + (p[i] >= 0 ? dp[p[i]] : 0);
    const exclude = i > 0 ? dp[i - 1] : 0;
    if (take[i] && include >= exclude) {
      selected.push(sorted[i]);
      i = p[i];
    } else {
      i -= 1;
    }
  }

  selected.reverse();
  const dpTable = sorted.map((job, idx) => ({
    index: idx,
    job,
    lastNonConflictingIndex: p[idx],
    dpValue: dp[idx],
  }));

  return {
    algorithm: "dp",
    maxProfit: dp.length ? dp[dp.length - 1] : 0,
    selectedJobs: selected,
    dpTable,
    complexity: { time: "O(n log n)", space: "O(n)" },
    engine: "node-fallback",
  };
}

function greedyScheduleJs(jobs) {
  const sorted = [...jobs]
    .map((job, index) => ({ ...job, originalIndex: index }))
    .sort((a, b) => a.end - b.end);

  const selected = [];
  let currentEnd = -Infinity;
  let total = 0;

  for (const job of sorted) {
    if (job.start >= currentEnd) {
      selected.push(job);
      currentEnd = job.end;
      total += job.profit;
    }
  }

  return {
    algorithm: "greedy",
    maxProfit: total,
    selectedJobs: selected,
    dpTable: [],
    complexity: { time: "O(n log n)", space: "O(n)" },
    engine: "node-fallback",
  };
}

function runPythonScheduler(payload) {
  const scriptPath = path.join(__dirname, "scheduler.py");
  const candidates = process.env.PYTHON_PATH
    ? [{ cmd: process.env.PYTHON_PATH, args: [] }]
    : process.platform === "win32"
      ? [
          { cmd: "python", args: [] },
          { cmd: "py", args: ["-3"] },
          { cmd: "python3", args: [] },
        ]
      : [
          { cmd: "python3", args: [] },
          { cmd: "python", args: [] },
        ];

  const tryRun = (index) =>
    new Promise((resolve, reject) => {
      if (index >= candidates.length) {
        reject(
          new Error(
            "No working Python executable found. Set PYTHON_PATH or install Python (python3/py)."
          )
        );
        return;
      }

      const current = candidates[index];
      const py = spawn(current.cmd, [...current.args, scriptPath], {
        stdio: ["pipe", "pipe", "pipe"],
      });

      let stdout = "";
      let stderr = "";

      py.stdout.on("data", (chunk) => {
        stdout += chunk.toString();
      });

      py.stderr.on("data", (chunk) => {
        stderr += chunk.toString();
      });

      py.on("error", () => {
        tryRun(index + 1).then(resolve).catch(reject);
      });

      py.on("close", (code) => {
        if (code !== 0) {
          const notFound =
            code === 9009 ||
            code === -4058 ||
            code === -2 ||
            /not found|cannot find|No such file|not recognized|install from the Microsoft Store/i.test(
              stderr
            );

          if (notFound) {
            tryRun(index + 1).then(resolve).catch(reject);
            return;
          }

          reject(
            new Error(
              `Python process exited with code ${code}. ${stderr || "No stderr output."}`
            )
          );
          return;
        }

        try {
          const parsed = JSON.parse(stdout);
          resolve(parsed);
        } catch (parseErr) {
          reject(
            new Error(
              `Failed to parse Python JSON output: ${parseErr.message}. Raw output: ${stdout}`
            )
          );
        }
      });

      py.stdin.write(JSON.stringify(payload));
      py.stdin.end();
    });

  return tryRun(0);
}

app.post("/schedule", async (req, res) => {
  try {
    const { jobs, algorithm } = req.body;

    if (!Array.isArray(jobs) || jobs.length === 0) {
      return res.status(400).json({
        error: "Invalid payload. 'jobs' must be a non-empty array.",
      });
    }

    for (const [index, job] of jobs.entries()) {
      const isValid =
        typeof job.start === "number" &&
        typeof job.end === "number" &&
        typeof job.profit === "number" &&
        job.start < job.end;

      if (!isValid) {
        return res.status(400).json({
          error: `Invalid job at index ${index}. Each job must have numeric start/end/profit and start < end.`,
        });
      }
    }

    const selectedAlgorithm = algorithm === "greedy" ? "greedy" : "dp";

    let result;
    try {
      result = await runPythonScheduler({
        jobs,
        algorithm: selectedAlgorithm,
      });
      result.engine = "python";
    } catch (pythonError) {
      // Fallback keeps app usable when Python is missing in PATH.
      if (/No working Python executable found/i.test(pythonError.message)) {
        result =
          selectedAlgorithm === "greedy"
            ? greedyScheduleJs(jobs)
            : weightedIntervalDpJs(jobs);
      } else {
        throw pythonError;
      }
    }

    return res.json(result);
  } catch (error) {
    return res.status(500).json({
      error: "Scheduling failed.",
      details: error.message,
    });
  }
});

app.get("/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Server running at http://localhost:${PORT}`);
});
